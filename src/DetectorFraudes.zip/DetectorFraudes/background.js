chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "checkUrl") {
        const apiKey = "TU_API_KEY";  // Usa una API como Google Safe Browsing
        const url = request.url;
        
        fetch(`https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${apiKey}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                client: { clientId: "tu_extensión", clientVersion: "1.0" },
                threatInfo: {
                    threatTypes: ["MALWARE", "SOCIAL_ENGINEERING"],
                    platformTypes: ["ANY_PLATFORM"],
                    threatEntryTypes: ["URL"],
                    threatEntries: [{ url: url }]
                }
            })
        })
        .then(response => response.json())
        .then(data => {
            sendResponse({ isSafe: Object.keys(data).length === 0 });
        })
        .catch(error => {
            console.error("Error verificando URL:", error);
            sendResponse({ isSafe: true });
        });
        return true;
    }
});
