document.querySelectorAll("a").forEach(link => {
    chrome.runtime.sendMessage({ action: "checkUrl", url: link.href }, response => {
        if (!response.isSafe) {
            link.style.color = "red";
            link.style.fontWeight = "bold";
            link.title = "¡Este enlace puede ser peligroso!";
        }
    });
});

// Monitoreo de mensajes en la web de Roblox
function checkRobloxMessages() {
    const suspiciousWords = ["Robux gratis", "dame tu contraseña", "haz clic aquí", "verificación de cuenta"];
    
    document.querySelectorAll(".text-content").forEach(message => {
        let text = message.innerText.toLowerCase();
        if (suspiciousWords.some(word => text.includes(word))) {
            message.style.backgroundColor = "yellow";
            message.style.fontWeight = "bold";
            message.title = "⚠️ Este mensaje podría ser un fraude";
        }
    });
}

// Ejecutar el chequeo cada 3 segundos en Roblox
if (window.location.hostname.includes("roblox.com")) {
    setInterval(checkRobloxMessages, 3000);
}
