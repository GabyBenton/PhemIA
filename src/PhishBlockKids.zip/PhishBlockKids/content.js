// Contenido del script de la extensión (content script)

// Parte 1: Chequeo de enlaces (con una pequeña mejora sugerida)
document.querySelectorAll("a").forEach(link => {
    // Es buena práctica verificar si 'chrome.runtime' y 'sendMessage' existen,
    // especialmente si el script pudiera ejecutarse en contextos inesperados.
    if (chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: "checkUrl", url: link.href }, response => {
            // Verificar que 'response' no sea undefined antes de acceder a sus propiedades
            if (response && !response.isSafe) {
                link.style.color = "red";
                link.style.fontWeight = "bold";
                link.title = "¡Este enlace puede ser peligroso!";
            }
        });
    }
});

// Parte 2: Monitoreo de mensajes en la web de Roblox (mejorado)
if (window.location.hostname.includes("roblox.com")) {

    const suspiciousPatterns = [
        /robux\s*gratis/i,
        /dame\s*tu\s*contraseña/i,
        /contraseña\s*gratis/i,
        /ingresa\s*tus\s*datos/i,
        /haz\s*clic\s*aqu[ií]\s*para\s*robux/i,
        /soporte\s*de\s*roblox.*contraseña/i,
        /verific(aci[oó]n|ar)\s*de\s*cuenta.*contraseña/i,
        /admin.*te\s*dar[eé]\s*robux/i,
        // Considera añadir patrones para enlaces sospechosos comunes o acortadores de URL
        // si se usan frecuentemente en estafas dentro de Roblox.
        // Ejemplo: /bit\.ly/i, /goo\.gl/i (¡pero cuidado con falsos positivos!)
    ];

    const processedMessages = new WeakSet(); // Para no procesar mensajes múltiples veces

    function flagMessage(messageElement) {
        if (processedMessages.has(messageElement) || !messageElement.innerText) {
            return; // Ya procesado o no tiene texto visible
        }

        let text = messageElement.innerText.toLowerCase();
        let isSuspicious = suspiciousPatterns.some(pattern => pattern.test(text));

        if (isSuspicious) {
            messageElement.style.backgroundColor = "yellow";
            messageElement.style.border = "2px solid red"; // Más visible
            messageElement.style.fontWeight = "bold";
            messageElement.title = "⚠️ ¡Este mensaje podría ser un intento de fraude o engaño!";
            console.log("Extensión: Mensaje sospechoso detectado:", messageElement.innerText);
        }
        processedMessages.add(messageElement);
    }

    function checkAllExistingMessages() {
        // Intenta ser lo más específico posible con el selector para los mensajes.
        // ".text-content" puede ser muy general. Inspecciona la web de Roblox
        // para encontrar un selector más preciso, como por ejemplo:
        // ".chat-message .text-content", ".message-bubble-content", etc.
        document.querySelectorAll(".text-content").forEach(flagMessage);
    }

    function observeMessages() {
        // ¡IMPORTANTE! Debes encontrar el selector correcto para el contenedor de chat en Roblox.
        // 'body' es demasiado general y muy ineficiente.
        // Inspecciona la página de chat de Roblox y busca el ID o la clase del elemento
        // que contiene los mensajes (ej: #chat-container, .chat-list, #message-pane).
        const chatContainerSelector = "span"; // <--- CAMBIA ESTO por el selector correcto
        const chatContainer = document.querySelector(chatContainerSelector);

        if (!chatContainer) {
            console.warn("Extensión: No se encontró el contenedor de chat de Roblox. El monitoreo de nuevos mensajes podría no funcionar. Selector usado:", chatContainerSelector);
            return;
        }

        const observer = new MutationObserver(mutationsList => {
            for (const mutation of mutationsList) {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // Si el nodo añadido es directamente un mensaje
                            if (node.matches && node.matches(".text-content")) { // Usa el mismo selector que en checkAllExistingMessages
                                flagMessage(node);
                            }
                            // O si el nodo añadido contiene elementos de mensaje
                            node.querySelectorAll(".text-content").forEach(flagMessage); // Usa el mismo selector
                        }
                    });
                }
                // Opcional: observar cambios en el texto de mensajes existentes
                // if (mutation.type === 'characterData' && mutation.target.parentElement) {
                //     const parentElement = mutation.target.parentElement;
                //     if (parentElement.matches && parentElement.matches(".text-content")) {
                //         processedMessages.delete(parentElement); // Marcar para re-evaluación
                //         flagMessage(parentElement);
                //     }
                // }
            }
        });

        observer.observe(chatContainer, {
            childList: true,  // Observar nodos hijos añadidos o eliminados
            subtree: true     // Observar también en los descendientes del 'chatContainer'
            // characterData: true, // Descomentar si quieres detectar cambios en el texto de mensajes ya existentes
            // characterDataOldValue: true // (si necesitas el valor antiguo)
        });
        console.log("Extensión: Monitoreo de mensajes de Roblox activado.");
    }

    // Asegurarse de que el DOM esté listo antes de ejecutar
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => {
            checkAllExistingMessages();
            observeMessages();
        });
    } else {
        checkAllExistingMessages();
        observeMessages();
    }
}