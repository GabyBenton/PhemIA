// background.js (Service Worker)

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "checkUrl") {
        // IMPORTANTE: Reemplaza "TU_API_KEY_AQUI" con tu clave de API real de Google Safe Browse.
        // NUNCA subas tu API key a repositorios públicos (ej. GitHub).
        // Considera usar variables de entorno o un sistema de configuración si vas a construir/distribuir la extensión.
        const apiKey = "TU_API_KEY_AQUI"; // <-- REEMPLAZA ESTO

        // IMPORTANTE: Personaliza el nombre de tu extensión para la API.
        const clientIdName = "DetectorDeFraudesRoblox"; // <-- PERSONALIZA ESTO
        const clientVersionName = "1.0";

        const apiUrl = `https://safeBrowse.googleapis.com/v4/threatMatches:find?key=${apiKey}`;
        const requestBody = {
            client: {
                clientId: clientIdName,
                clientVersion: clientVersionName
            },
            threatInfo: {
                threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
                platformTypes: ["ANY_PLATFORM"],
                threatEntryTypes: ["URL"],
                threatEntries: [{ url: request.url }]
            }
        };

        fetch(apiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestBody)
        })
        .then(response => {
            if (!response.ok) {
                // Si la respuesta HTTP no es exitosa (ej. 4xx, 5xx),
                // lanza un error para que sea capturado por el .catch()
                throw new Error(`Error de API: ${response.status} ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            // Si 'data' tiene claves (es decir, no es un objeto vacío {}), significa que hubo coincidencias (amenazas).
            // Un objeto vacío {} significa que la URL es segura según los criterios de Safe Browse.
            const isMalicious = data && Object.keys(data).length > 0;
            sendResponse({ isSafe: !isMalicious });
        })
        .catch(error => {
            console.error("Error verificando URL con Safe Browse API:", error.message, "URL:", request.url);
            // En caso de error (red, API, etc.), es más seguro asumir que la URL podría no ser segura
            // o indicar un estado de error. Aquí enviamos 'isSafe: false' para ser cautelosos.
            // El content script marcará el enlace como peligroso.
            // Alternativamente, podrías enviar un estado de error específico:
            // sendResponse({ error: true, isSafe: null, message: error.message });
            // y luego el content_script tendría que manejar este estado de error.
            sendResponse({ isSafe: false, errorOccurred: true });
        });

        return true; // Indica que sendResponse se llamará de forma asíncrona.
    }
});

// Opcional: Escuchar eventos de instalación/actualización para guiar al usuario
chrome.runtime.onInstalled.addListener(details => {
    if (details.reason === "install") {
        console.log("Extensión instalada. Asegúrate de configurar tu API Key si es necesario.");
        // Podrías abrir una página de bienvenida o configuración aquí.
        // chrome.tabs.create({ url: "options.html" });
    }
});